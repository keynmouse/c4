import sys
import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PointStamped
from std_msgs.msg import Header
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton, QVBoxLayout
from PyQt5.QtCore import QThread

# ROS 2 퍼블리셔를 만드는 클래스
class RosPublisherNode(Node):
    def __init__(self):
        super().__init__('pyqt_ros_publisher')
        self.publisher = self.create_publisher(PointStamped, 'point_stamped_topic', 10)

    def publish_point(self, x, y, z):
        # Header 설정
        header = Header()
        header.stamp = self.get_clock().now().to_msg()  # 현재 시간 설정
        header.frame_id = "map"  # 메시지가 참조하는 좌표계 (여기선 "map"으로 설정)

        # Point 설정
        point = PointStamped()
        point.header = header
        point.point.x = x
        point.point.y = y
        point.point.z = z

        # 퍼블리시
        self.publisher.publish(point)
        self.get_logger().info(f'Published PointStamped: ({x}, {y}, {z})')

# ROS 2 spin을 별도의 스레드에서 실행할 클래스
class RosSpinThread(QThread):
    def __init__(self, node):
        super().__init__()
        self.node = node

    def run(self):
        rclpy.spin(self.node)

# PyQt5 윈도우와 버튼을 만드는 클래스
class MyApp(QWidget):
    def __init__(self, ros_node):
        super().__init__()

        # ROS 2 노드 인스턴스
        self.ros_node = ros_node

        # PyQt 윈도우 설정
        self.setWindowTitle("ROS 2 PyQt Button Example")
        self.setGeometry(100, 100, 300, 200)

        # 버튼 생성
        self.button1 = QPushButton('table A', self)
        self.button2 = QPushButton('table B', self)
        self.button3 = QPushButton('table C', self)

        # 버튼 클릭 이벤트 설정
        self.button1.clicked.connect(lambda: self.on_button_click(1.0, 2.0, 0.0))
        self.button2.clicked.connect(lambda: self.on_button_click(1.5, 2.5, 0.0))
        self.button3.clicked.connect(lambda: self.on_button_click(2.0, 2.0, 0.0))

        # 레이아웃 설정
        layout = QVBoxLayout()
        layout.addWidget(self.button1)
        layout.addWidget(self.button2)
        layout.addWidget(self.button3)

        self.setLayout(layout)

    def on_button_click(self, x, y, z):
        self.ros_node.publish_point(x, y, z)

def main(args=None):
    rclpy.init(args=args)

    # ROS 2 노드 생성
    ros_node = RosPublisherNode()

    # ROS 2 spin을 별도의 스레드에서 실행
    ros_spin_thread = RosSpinThread(ros_node)
    ros_spin_thread.start()

    # PyQt 애플리케이션 생성
    app = QApplication(sys.argv)
    gui = MyApp(ros_node)

    # GUI 실행
    gui.show()

    # PyQt 이벤트 루프 실행
    app.exec_()

    # 종료 처리
    ros_node.destroy_node()
    rclpy.shutdown()
    ros_spin_thread.quit()
    ros_spin_thread.wait()

if __name__ == '__main__':
    main()
